CREATE function getSumPByUnitid(vunitid in number)
return varchar2
as
   sump number(10);
begin
   select count(1) into sump from users  where unitid=vunitid and usertype=13 and status='1';
   return sump;
end;
/
