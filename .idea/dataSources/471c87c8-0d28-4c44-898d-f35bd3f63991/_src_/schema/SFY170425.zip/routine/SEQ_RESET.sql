CREATE procedure seq_reset(v_seqname varchar2) as n number(10);
tsql varchar2(500); scnt number(10);
begin
     execute immediate 'select xxjyz.'||v_seqname||'.nextval from dual' into n;
     
     execute immediate 'select count(*) FROM All_Sequences where sequence_name=upper('''||v_seqname||''') and sequence_owner=''WLFW'' ' into scnt;
     
     if(scnt>0) then
          tsql:='drop sequence '||v_seqname ;
          execute immediate tsql;  
     end if;
      

     tsql:='create sequence '||v_seqname||' minvalue 1 maxvalue 999999999999999999999999999 start with '||n||' increment by 1 cache 20';
     execute immediate tsql;
     execute immediate 'select '||v_seqname||'.nextval from dual';
     execute immediate 'select '||v_seqname||'.nextval from dual';
      
end seq_reset;
/
